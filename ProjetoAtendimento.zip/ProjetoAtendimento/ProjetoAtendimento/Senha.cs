﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAtendimento
{
    public class Senha
    {
        public int Id { get; private set; }

        public DateTime DataGerac { get; private set; }

        public DateTime HoraGerac { get; private set; }

        public DateTime? DataAtend { get; private set; } 

       public DateTime? HoraAtend { get; private set; } 

 

    public Senha(int id)

{

    Id = id;

    DataGerac = DateTime.Now.Date;

    HoraGerac = DateTime.Now;

}



         public string DadosParciais() 

    {

    return $"{ Id} – { DataGerac: dd / MM / yyyy} – { HoraGerac: HH: mm: ss}”;

}



        public string DadosCompletos() 

    {

    return $"{ Id} – { DataGerac: dd / MM / yyyy} – { HoraGerac: HH: mm: ss} – { DataAtend: dd / MM / yyyy} – { HoraAtend: HH: mm: ss}”;

}



public void RegistrarAtendimento() 

    {

    DataAtend = DateTime.Now.Date;

    HoraAtend = DateTime.Now;

} 
    }

}

