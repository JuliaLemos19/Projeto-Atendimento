﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAtendimento
{
    internal class Guiche
    {
        public int Id { get; private set; }

        private Queue<Senha> Atendimentos;



        public Guiche(int id)

        {

            Id = id;

            Atendimentos = new Queue<Senha>();

        }



        public bool Chamar(Queue<Senha> filaSenhas)

        {

            if (filaSenhas.Count > 0)
    
        {

                var senha = filaSenhas.Dequeue();

                senha.RegistrarAtendimento();

                Atendimentos.Enqueue(senha);

                return true;

            }

            return false;

        }



        public Queue<Senha> ObterAtendimentos()
    
    {

            return Atendimentos;

        }

    
}
}
