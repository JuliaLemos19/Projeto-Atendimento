﻿using System;
using System.Windows.Forms;

namespace ProjetoAtendimento
{
    public partial class Form1 : Form
    {
        private Senhas Senhas;
        private Guiches Guiches;

        public Form1()
        {
            InitializeComponent();
            Senhas = new Senhas();
            Guiches = new Guiches();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            Senhas.Gerar();
            AtualizarListaSenhas();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            var guiche = new Guiche(Guiches.ObterLista().Count + 1);
            Guiches.Adicionar(guiche);
            AtualizarQtdGuiches();
        }

        private void btnChamar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtGuiche.Text, out int idGuiche) && idGuiche > 0 && idGuiche <= Guiches.ObterLista().Count)
            {
                var guiche = Guiches.ObterLista()[idGuiche - 1];

                if (guiche.Chamar(Senhas.ObterFila()))
                {
                    AtualizarListaSenhas();
                    AtualizarListaAtendimentos(guiche);
                }
                else
                {
                    MessageBox.Show("Fila vazia!");
                }
            }
            else
            {
                MessageBox.Show("Guichê inválido!");
            }
        }

        private void AtualizarListaSenhas()
        {
            lsSenhas.Items.Clear();
            foreach (var senha in Senhas.ObterFila())
            {
                lsSenhas.Items.Add(senha.DadosParciais());

            }
        }
    }

}