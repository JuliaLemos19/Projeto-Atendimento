﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoAtendimento
{
    internal class Senhas
    {
        private int proximoAtendimento;

        private Queue<Senha> filaSenhas;



        public Senhas()

        {

            filaSenhas = new Queue<Senha>();

            proximoAtendimento = 1;

        }



        public void Gerar()

        {

            var novaSenha = new Senha(proximoAtendimento++);

            filaSenhas.Enqueue(novaSenha);

        }



        public Queue<Senha> ObterFila()
    
    {

            return filaSenhas;

        }

    
}
}
