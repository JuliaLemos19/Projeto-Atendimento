﻿namespace ProjetoAtendimento
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.lsrSenhas = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.lsSenhas = new System.Windows.Forms.TextBox();
            this.lsAtendimentos = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AtualizarQtdGuiches = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(93, 109);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Gerar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnGerar_Click);
            // 
            // lsrSenhas
            // 
            this.lsrSenhas.Location = new System.Drawing.Point(71, 300);
            this.lsrSenhas.Name = "lsrSenhas";
            this.lsrSenhas.Size = new System.Drawing.Size(111, 23);
            this.lsrSenhas.TabIndex = 1;
            this.lsrSenhas.Text = "Listar Senhas";
            this.lsrSenhas.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(258, 220);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Adicionar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(385, 303);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(185, 20);
            this.button5.TabIndex = 3;
            this.button5.Text = "Listar Atendimentos";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(527, 107);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 4;
            this.button6.Text = "Chamar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btnChamar_Click);
            // 
            // lsSenhas
            // 
            this.lsSenhas.Location = new System.Drawing.Point(35, 137);
            this.lsSenhas.Multiline = true;
            this.lsSenhas.Name = "lsSenhas";
            this.lsSenhas.Size = new System.Drawing.Size(187, 157);
            this.lsSenhas.TabIndex = 5;
            // 
            // lsAtendimentos
            // 
            this.lsAtendimentos.Location = new System.Drawing.Point(353, 137);
            this.lsAtendimentos.Multiline = true;
            this.lsAtendimentos.Name = "lsAtendimentos";
            this.lsAtendimentos.Size = new System.Drawing.Size(272, 157);
            this.lsAtendimentos.TabIndex = 6;
            this.lsAtendimentos.Text = " ";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(421, 109);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(263, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Qtde guichês";
            // 
            // AtualizarQtdGuiches
            // 
            this.AtualizarQtdGuiches.AutoSize = true;
            this.AtualizarQtdGuiches.Location = new System.Drawing.Point(278, 187);
            this.AtualizarQtdGuiches.Name = "AtualizarQtdGuiches";
            this.AtualizarQtdGuiches.Size = new System.Drawing.Size(35, 13);
            this.AtualizarQtdGuiches.TabIndex = 9;
            this.AtualizarQtdGuiches.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Guiche:";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(720, 435);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AtualizarQtdGuiches);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lsAtendimentos);
            this.Controls.Add(this.lsSenhas);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.lsrSenhas);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGerar;
        private System.Windows.Forms.Button lstSenhas;
        private System.Windows.Forms.Button btnAdicionar;
        private System.Windows.Forms.Button btnChamar;
        private System.Windows.Forms.Button lstAtendimentos;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblQtdeGuiches;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtGuiche;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button lsrSenhas;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox lsSenhas;
        private System.Windows.Forms.TextBox lsAtendimentos;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label AtualizarQtdGuiches;
        private System.Windows.Forms.Label label5;
    }
}

